﻿namespace CollectionOfHierarchy.Contracts
{
    interface IAdd
    {
        int Add(string text);
    }
}
