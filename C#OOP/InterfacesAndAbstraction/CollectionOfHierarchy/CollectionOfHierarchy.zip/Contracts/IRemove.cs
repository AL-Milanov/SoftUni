﻿namespace CollectionOfHierarchy.Contracts
{
    interface IRemove
    {
        string Remove();
    }
}
